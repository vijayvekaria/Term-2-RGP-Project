package src;

public class NewWheelMotionTest {
	public static void main(String[] args) {
//		Driver.moveCells(1);
//		try {Thread.sleep(200);} catch (InterruptedException e) {}
//		Driver.moveToNextLineSegment();
//		try {Thread.sleep(200);} catch (InterruptedException e) {}
//		Driver.moveCellsBack(2);
//		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(180);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(-90);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(180);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(180);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(-90);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(180);
		try {Thread.sleep(200);} catch (InterruptedException e) {}
		Driver.rotateTo(-90);
	}
}
