package src;

import java.util.ArrayList;

import lejos.hardware.Sound;


public class Task2 {
	static ArrayList<int[]> pathGo;
	public Task2() {
		//GyroSensor.initialiseSensor();
		final Grid grid = new Grid();
//		final ArrayList<int[]>  path1 = null;
		new Thread(new Runnable() {
			ArrayList<int[]> tmpPath;
			@Override
			public void run() {
				try { tmpPath =  PathPlanner.GetOptimalPath(grid, grid.getCell(17, 4), grid.getCell(10, 20)); } catch (PathNotFoundException e) {System.out.println("No path found no.1"); }
				Task2.passPath(tmpPath);
				
			}
		}).start();
		
		
		Localiser.start();
		
		
		
		Driver.traversePath(pathGo);
		
		grid.blockLeftReturnPath();
		
		new Thread(new Runnable() {
			ArrayList<int[]> tmpPath;

			@Override
			public void run() {
				try { tmpPath =  PathPlanner.GetOptimalPath(grid, grid.getCell(10, 17), grid.getCell(18, 4)); } catch (PathNotFoundException e) {System.out.println("No path found no.2");}	
				Task2.passPath(tmpPath);
				
			}
		}).start();
			
		Goal.enterGoal(grid);
	
		Driver.rotateTo(0);
		Driver.moveCellsBack(3);
		
		Driver.rotateTo(90);
		
		Driver.traversePath(pathGo);
		
		Driver.rotateTo(180);
		
		Driver.setMotorSpeed(500);
		Driver.moveForward();
		
		while(!Button.ispressed()){
			
		}
		Driver.stop();
		
		Sound.beep();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	protected static void passPath(ArrayList<int[]> tmpPath) {
		pathGo = tmpPath;
		
	}
	public static void main(String[] args) {
		new Task2();
	}
}
