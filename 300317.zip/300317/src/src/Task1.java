package src;

import java.util.ArrayList;
import lejos.hardware.Sound;


public class Task1 {
	static ArrayList<int[]> pathGo;
	public Task1() {
		
		GyroSensor.initialiseSensor();
		
		final Grid grid = new Grid();
		
		new Thread(new Runnable() {
			ArrayList<int[]> tmpPath;
			@Override
			public void run() {
				try { tmpPath =  PathPlanner.GetOptimalPath(grid, grid.getCell(17, 4), grid.getCell(10, 20)); } catch (PathNotFoundException e) {System.out.println("No path found no.1"); }
				Task1.passPath(tmpPath);
				
			}
		}).start();

		Localiser.start();

		Driver.traversePath(pathGo);
		
		grid.blockRightSection();
		
		new Thread(new Runnable() {
			ArrayList<int[]> tmpPath;
			public void run() {
				try { tmpPath =  PathPlanner.GetOptimalPath(grid, grid.getCell(10, 17), grid.getCell(16, 4)); } catch (PathNotFoundException e) {System.out.println("No path found no.2");}	
				Task1.passPath(tmpPath);
				
			}
		}).start();

	
		Driver.rotateTo(0);
		Driver.moveCellsBack(3);
		//Driver.rotateTo(90);
		
		Driver.traversePath(pathGo);
		
		Driver.rotateTo(180);
		Driver.setMotorSpeed(500);
		Driver.moveForward();
		
		while(!Button.ispressed()){}
		Driver.stop();
		Sound.beep();
	}
	
	protected static void passPath(ArrayList<int[]> tmpPath) {
		pathGo = tmpPath;
	}
	
	public static void main(String[] args) {
		new Task1();
	}
}
