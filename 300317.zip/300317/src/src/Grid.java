package src;

public class Grid {
	private static int xLength = 35;
	private static int yLength = 26;
	
	private static Cell[][] grid = new Cell[xLength][yLength];
	
	private static final int firstBlockLocation = 2; //1 = left, 2 = middle
	
	/*
	 * START: [17][4]
	 * GOAL : [11][20]
	 * 
	 */
	
	public Grid() {
		createGrid();
		setFalseHeuristics();
		//printGrid();
	}

	private void createGrid() {
		for (int y = 0; y < yLength; ++y){
			for (int x = 0; x < xLength; ++x){
				grid[x][y] = new Cell(x, y);
			}
		}
	}

	private void setFalseHeuristics() {
		generateBorders();
		generateWall();
		generateObstacles();
	}

	public void generateBorders(){
		//ALL BORDERS WITH 3 CELLS OF PADDING
		//Borders are actually 12 by 12 triangles
		
		int bottomLeft = 16;
		for (int y = 0; y < 13; ++y){
			for (int x = bottomLeft; x >= 0; --x){
				grid[x][y].setTraversable(false);
			}
			bottomLeft--;
		}
		
		int topLeft = 14; 
		for (int y = yLength - 1; y >= yLength - 1 - 12; --y){
			for (int x = topLeft; x >= 0; --x){
				grid[x][y].setTraversable(false);
			}
			topLeft--;
		}
		
		int bottomRight = 15;
		for (int y = 0; y < 13; ++y){
			for (int x = xLength - 1; x >= xLength - 1 - bottomRight; --x){
				grid[x][y].setTraversable(false);
			}
			bottomRight--;
		}
		
		int topRight = 15;
		for (int y = yLength - 1; y >= yLength - 1 - 12; --y){
			for (int x = xLength - 1; x >= xLength - 1 - topRight; --x){
				grid[x][y].setTraversable(false);
			}
			topRight--;
		}
	}
	
	public void generateWall() {
		//WALL WITH SINGLE CELL PADDING TOP & BOTTOM.
		for (int y = 11; y < 15; ++y){
			for (int x = 12; x < 23; ++x){
				grid[x][y].setTraversable(false);
			}
		}
		
		//GENERATE GOAL WALL
		for (int y = 19; y < 22; ++y){
			grid[11][y].setTraversable(false);
		}
	}
	
	public void blockLeftReturnPath(){
		for (int x = 0; x < 17; ++x){
			grid[x][14].setTraversable(false);
		}
	}
	
	public void blockRightSection(){
		for (int y = 0; y < yLength; ++y){
			for (int x = 17; x < xLength; ++x){
				grid[x][y].setTraversable(false);
			}
		}
	}
	
	private void generateObstacles() {
		//OBSTACLES WITH SINGLE CELL PADDING TOP & BOTTOM.
		if (firstBlockLocation == 2){
			//Obstacle 1
			for (int y = 11; y < 15; ++y){
				for (int x = 9; x < 11; ++x){
					grid[x][y].setTraversable(false);
				}
			}
		} else {
			//Obstacle 2
			for (int y = 11; y < 15; ++y){
				for (int x = 5; x < 7; ++x){
					grid[x][y].setTraversable(false);
				}
			}
		}
	}

	public void setRed() {
		for (int y = 11; y < 15; ++y){
			for (int x = 28; x < 30; ++x){
				grid[x][y].setTraversable(false);
			}
		}
	}

	public void setGreen() {
		for (int y = 11; y < 15; ++y){
			for (int x = 24; x < 26; ++x){
				grid[x][y].setTraversable(false);
			}
		}
	}
	
	public Cell getCell(int x, int y){
		return grid[x][y];
	}

	public int getXLength() {
		return xLength;
	}
	
	public int getYHeight() {
		return yLength;
	}
	public void printGrid(){
		int yCount = yLength - 1;
		for (int y = yLength - 1; y >= 0 ; --y){
			for (int x = 0; x < xLength; ++x){
				if(!grid[x][y].getTraversable())
				{
					System.out.print("X "); //("\u001B[41m" + "\u001B[31m" + "X " + "\u001B[0m");
				}
				else if(grid[x][y].isPartOfPath()){
					System.out.print("# "); //("\u001B[42m" + "\u001B[32m" + "# " + "\u001B[0m");

				}
				else
				{
					System.out.print("O "); //("\u001B[47m" + "\u001B[37m" + "O " + "\u001B[0m");
				}
			}
			System.out.println("  " + yCount--);
		}
		for (int i = 0; i < xLength; ++i){
			System.out.print((i % 10) + " ");
		}
	}
}