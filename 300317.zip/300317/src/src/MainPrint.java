package src;

import java.util.ArrayList;

import lejos.hardware.Sound;


public class MainPrint {
	public MainPrint() {
		Grid grid = new Grid();	
		ArrayList<int[]> path = null;
		try { path =  PathPlanner.GetOptimalPath(grid, grid.getCell(17, 4), grid.getCell(10, 20)); } catch (PathNotFoundException e) {System.out.println("No path found no.1"); }
		grid.blockRightSection();
		try { path =  PathPlanner.GetOptimalPath(grid, grid.getCell(10, 20), grid.getCell(16, 4)); } catch (PathNotFoundException e) {System.out.println("No path found no.2");}	
		//grid.printGrid();
	}
	public static void main(String[] args) {
		MainPrint main = new MainPrint();
	}
}
